<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>New Registartion</title>
    <link rel="stylesheet" href="css\style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel = "icon" href = "images/logo.png" type = "image/x-icon">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>

<body   >
    <!--Navigation-->
    <?php include_once("header.html"); ?>


<center>

    <form action="regis.php" method="post" id="regform" style="display: none; margin-top: 10%; border:2px solid black; width: 30%; padding: 2% 2% 2% 2%; background-color: silver; border-radius: 5px;" >
      <div class="form-group"><strong>
        <label for="email" >Vehicle No.</label>
        <input type="text" name="vehicle" class="form-control" style="widh: 20%;">
    </div>
    <div class="form-group">
        <label for="pwd">MAC ID</label></strong>
        <input type="text" class="form-control" style="widh: 20%;" name="mac">
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
<br><br>
<center>
    <div class="form-group " id="checkcom" style="margin-top: 5%;">
        <b>Enter the company password</b>
        <br><br>
        <input type="password" id=cp><br><br>
        <button onclick="fff()" class="btn btn-primary">SUBMIT</button>
    </div>



</center>






<?php include_once("footer.html"); ?>
<script src="script.js"></script>

</div>
</body>
</html>

