<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Monthly List</title>
	<link rel="stylesheet" href="css\style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel = "icon" href = "images/logo.png" type = "image/x-icon">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	<!-- Popper JS -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>

<body >
	<!--Navigation-->
	
	<?php include_once("header.html"); ?>
	<hr>
	<!-- <br><br> -->
	<!--image slider-->
	<br><br>
	<div class="row">
		
			<div class="form-group col" style="padding-left: 15%; border-right: 2px solid black;" >
				<form action="def.php" method="post">
				<center>
					<b>Retreive Defaulters</b>
					<br><br>
					<input type="password" name="defaulter" placeholder="password"><br><br>
					<button  class="btn btn-primary">SUBMIT</button>
				</center>
				</form>
			</div>


				<div class="form-group col " style="padding-right: 15%;" >
					<form action="rec.php" method="post">
					<center>
						<b>Enter the Vehicle Number</b>
						<br><br>
						<input type="text" name ="record" placeholder="Enter Vehicle Number"><br><br>
						<button  class="btn btn-primary">SUBMIT</button>
					</center>
					</form>
				</div>
			
		</div>

		<?php include_once("footer.html"); ?>
		<script src="script.js"></script>

	</div>
</body>
</html>